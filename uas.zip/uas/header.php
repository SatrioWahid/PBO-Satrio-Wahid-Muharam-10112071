<?php
require_once __DIR__ . '/class/Auth.php';
$auth = new Auth();
$auth->checkAuth();

$base_url = "http://" . $_SERVER['HTTP_HOST'] . "/uas";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi Stok Gudang Barang</title>
    <link rel="stylesheet" href="<?php echo $base_url; ?>/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css">
</head>
<body>
    
    <div class="app-container">
        
        <aside class="sidebar">
            <div class="sidebar-brand">
                <i class="mdi mdi-view-grid"></i> INVENTORY SYSTEM
            </div>
            
            <ul class="sidebar-menu">
                <li>
                    <a href="<?php echo $base_url; ?>/beranda.php">
                        <i class="mdi mdi-clock-outline"></i> Dashboard
                    </a>
                </li>
                
                <li class="menu-header">MASTER DATA</li>
                <li><a href="<?php echo $base_url; ?>/jenis/index.php"><i class="mdi mdi-cube-outline"></i> Data Gudang</a></li>
                <li><a href="<?php echo $base_url; ?>/barang/index.php"><i class="mdi mdi-package-variant-closed"></i> Data Barang</a></li>
                
                <?php if (isset($_SESSION['tipe_user']) && $_SESSION['tipe_user'] == 'admin') { ?>
                <li><a href="<?php echo $base_url; ?>/satuan/index.php"><i class="mdi mdi-layers-outline"></i> Data Satuan</a></li>
                <?php } ?>
                
                <li><a href="<?php echo $base_url; ?>/customer/index.php"><i class="mdi mdi-account-group-outline"></i> Data Customer</a></li>
                <li><a href="<?php echo $base_url; ?>/supplier/index.php"><i class="mdi mdi-truck-outline"></i> Data Supplier</a></li>
                <li><a href="<?php echo $base_url; ?>/user/index.php"><i class="mdi mdi-account-cog-outline"></i> Data Pengguna</a></li>

                <li class="menu-header">TRANSAKSI</li>
                <li><a href="<?php echo $base_url; ?>/pembelian/index.php"><i class="mdi mdi-calendar-text-outline"></i> Pembelian</a></li>
                <li><a href="<?php echo $base_url; ?>/penjualan/index.php"><i class="mdi mdi-cart-outline"></i> Penjualan</a></li>

                <li class="menu-header">LAPORAN</li>
                <li><a href="<?php echo $base_url; ?>/laporan/index.php"><i class="mdi mdi-chart-bar"></i> Laporan Penjualan</a></li>

                <li class="menu-header">PENGATURAN</li>
                <li>
                    <a href="<?php echo $base_url; ?>/logout.php" class="text-danger">
                        <i class="mdi mdi-logout"></i> Logout
                    </a>
                </li>
            </ul>
        </aside>

        <div class="main-wrapper">
            <div class="main-content">