<?php
session_start();
include('../../koneksi.php');
if(!isset($_SESSION['username'])){
    header("Location: ../../login.php");
    exit;
}
if($_SESSION['tipe_user'] != 'Administrator'){
    header("Location: ../../login.php");
    exit;
}
if(!isset($_GET['kd_barang']) || empty($_GET['kd_barang'])){
    echo "<script>alert('Kode barang tidak ditemukan!');window.location='data_barang.php';</script>";
    exit;
}

$kd_barang = $_GET['kd_barang'];
$row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_barang WHERE kd_barang='$kd_barang'"));

if(!$row){
    echo "<script>alert('Data tidak ditemukan!');window.location='data_barang.php';</script>";
    exit;
}

$jenis = mysqli_query($conn, "SELECT * FROM tb_jenis");

if(isset($_POST['submit'])){
    $kode_jenis  = $_POST['kode_jenis'];
    $nama_barang = $_POST['nama_barang'];
    $stok        = $_POST['stok'];
    $harga_beli  = $_POST['harga_beli'];
    $harga_jual  = $_POST['harga_jual'];
    $gambar      = $row['gambar_produk']; // default gambar lama

    if(!empty($_FILES['gambar_produk']['name'])){
        // Hapus gambar lama jika ada
        if(!empty($row['gambar_produk'])){
            $file_lama = "../../gambar/" . $row['gambar_produk'];
            if(file_exists($file_lama)) unlink($file_lama);
        }
        $nama_file = time() . "_" . $_FILES['gambar_produk']['name'];
        $target    = "../../gambar/" . $nama_file;
        move_uploaded_file($_FILES['gambar_produk']['tmp_name'], $target);
        $gambar = $nama_file;
    }

    mysqli_query($conn, "UPDATE tb_barang SET 
        kode_jenis='$kode_jenis', nama_barang='$nama_barang',
        stok=$stok, harga_beli=$harga_beli, harga_jual=$harga_jual,
        gambar_produk='$gambar'
        WHERE kd_barang='$kd_barang'");

    echo "<script>alert('Data berhasil diupdate!');window.location='data_barang.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
  .sidebar .nav .sub-menu .nav-item .nav-link {
    white-space: normal;
  }
</style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Edit Data Barang</title>
  <link rel="stylesheet" href="../../assets/spica/vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="../../assets/spica/vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="../../assets/spica/css/style.css">
  <link rel="shortcut icon" href="../../assets/spica/images/favicon.png" />
</head>
<body>
<div class="container-scroller d-flex">

  <nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
      <li class="nav-item sidebar-category"><p>Navigation</p><span></span></li>
      <li class="nav-item">
        <a class="nav-link" href="index_admin.php">
          <i class="mdi mdi-view-quilt menu-icon"></i>
          <span class="menu-title">Dashboard Admin</span>
        </a>
      </li>
      <li class="nav-item sidebar-category"><p>Components</p><span></span></li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="true">
          <i class="mdi mdi-view-headline menu-icon"></i>
          <span class="menu-title">Kelola Data</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse show" id="ui-basic">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"><a class="nav-link active" href="data_barang.php">Data Barang</a></li>
            <li class="nav-item"><a class="nav-link" href="data_customer.php">Data Customer</a></li>
            <li class="nav-item"><a class="nav-link" href="data_supplier.php">Data Supplier</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#auth" aria-expanded="false">
          <i class="mdi mdi-view-headline menu-icon"></i>
          <span class="menu-title">Kelola Transaksi</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="auth">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"><a class="nav-link" href="transaksi_pembelian.php">Transaksi Pembelian</a></li>
            <li class="nav-item"><a class="nav-link" href="transaksi_penjualan.php">Transaksi Penjualan</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#auth2" aria-expanded="false">
          <i class="mdi mdi-view-headline menu-icon"></i>
          <span class="menu-title">Kelola Laporan</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="auth2">
          <ul class="nav flex-column sub-menu">
           <li class="nav-item"><a class="nav-link" href="laporan_pembelian.php">Laporan Transaksi Pembelian</a></li>
            <li class="nav-item"><a class="nav-link" href="laporan_penjualan.php">Laporan Transaksi Penjualan</a></li>
            <li class="nav-item"><a class="nav-link" href="laporan_customer.php">Laporan Data Customer</a></li>
            <li class="nav-item"><a class="nav-link" href="laporan_supplier.php">Laporan Data Supplier</a></li>
          </ul>
        </div>
      </li>
        <li class="nav-item">
        <a class="nav-link" href="profil.php">
          <i class="mdi mdi-account menu-icon"></i>
          <span class="menu-title">Profil Saya</span>
        </a>
      </li>
    </ul>
  </nav>

  <div class="container-fluid page-body-wrapper">
    <nav class="navbar col-lg-12 col-12 px-0 py-0 py-lg-4 d-flex flex-row">
          <?php include('navbar.php'); ?> 
    </nav>

    <div class="main-panel">
      <div class="content-wrapper">
        <div class="row">
          <div class="col-md-8 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                  <h4 class="card-title mb-0">Edit Data Barang</h4>
                  <a href="data_barang.php" class="btn btn-danger btn-sm">Kembali</a>
                </div>
                <form method="POST" enctype="multipart/form-data">
                  <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Kode Barang</label>
                    <div class="col-sm-8">
                      <input type="text" class="form-control bg-light" value="<?php echo $row['kd_barang']; ?>" readonly>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Jenis Barang</label>
                    <div class="col-sm-8">
                      <select class="form-control" name="kode_jenis" required>
                        <option value="">Pilih Jenis</option>
                        <?php while($j = mysqli_fetch_assoc($jenis)): ?>
                          <option value="<?php echo $j['kode_jenis']; ?>"
                            <?php echo ($row['kode_jenis'] == $j['kode_jenis']) ? 'selected' : ''; ?>>
                            <?php echo $j['jenis']; ?>
                          </option>
                        <?php endwhile; ?>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Nama Barang</label>
                    <div class="col-sm-8">
                      <input type="text" class="form-control" name="nama_barang" value="<?php echo $row['nama_barang']; ?>" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Stok</label>
                    <div class="col-sm-8">
                      <input type="number" class="form-control" name="stok" value="<?php echo $row['stok']; ?>" min="0" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Harga Beli</label>
                    <div class="col-sm-8">
                      <input type="number" class="form-control" name="harga_beli" value="<?php echo $row['harga_beli']; ?>" min="0" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Harga Jual</label>
                    <div class="col-sm-8">
                      <input type="number" class="form-control" name="harga_jual" value="<?php echo $row['harga_jual']; ?>" min="0" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Gambar Produk</label>
                    <div class="col-sm-8">
                      <?php if($row['gambar_produk']): ?>
                        <img src="../../gambar/<?php echo $row['gambar_produk']; ?>" width="80" height="60" style="object-fit:cover; border-radius:4px;" class="mb-2 d-block">
                      <?php endif; ?>
                      <input type="file" class="form-control" name="gambar_produk" accept="image/*">
                      <small class="text-muted">Kosongkan jika tidak ingin mengubah gambar</small>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-sm-8 offset-sm-4">
                      <button type="submit" name="submit" class="btn btn-success me-2">Update</button>
                      <a href="data_barang.php" class="btn btn-danger">Batal</a>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="../../assets/spica/vendors/js/vendor.bundle.base.js"></script>
<script src="../../assets/spica/vendors/chart.js/Chart.min.js"></script>
<script src="../../assets/spica/js/jquery.cookie.js"></script>
<script src="../../assets/spica/js/off-canvas.js"></script>
<script src="../../assets/spica/js/hoverable-collapse.js"></script>
<script src="../../assets/spica/js/template.js"></script>
</body>
</html>